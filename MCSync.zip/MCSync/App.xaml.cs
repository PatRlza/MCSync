using System.Windows;

namespace MCSync
{
    public partial class App : Application
    {
    }
}
