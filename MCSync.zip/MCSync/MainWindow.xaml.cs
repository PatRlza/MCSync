using System;
using System.Collections.ObjectModel;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Security.Cryptography;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using MCSync.Models;
using MCSync.Services;

namespace MCSync
{
    // Row shown in the Player tab's "required programs" list.
    public class ToolStatusVM
    {
        public string Name { get; set; } = "";
        public string DownloadUrl { get; set; } = "";
        public string StatusText { get; set; } = "";
        public Visibility InstallButtonVisibility { get; set; }
    }

    public partial class MainWindow : Window
    {
        private readonly AppConfig _config = AppConfig.Load();
        private readonly ObservableCollection<PackageEntry> _packages = new();
        private readonly ObservableCollection<ToolStatusVM> _tools = new();
        private Manifest? _lastManifest;

        public MainWindow()
        {
            InitializeComponent();
            PackagesList.ItemsSource = _packages;
            ToolsList.ItemsSource = _tools;

            ClientOwnerBox.Text = string.IsNullOrWhiteSpace(_config.GitHubOwner) ? Secrets.DefaultGitHubOwner : _config.GitHubOwner;
            ClientRepoBox.Text = string.IsNullOrWhiteSpace(_config.GitHubRepo) ? Secrets.DefaultGitHubRepo : _config.GitHubRepo;
            InstallPathBox.Text = string.IsNullOrWhiteSpace(_config.InstallPath)
                ? MinecraftPaths.DefaultDotMinecraft()
                : _config.InstallPath;
            ModsCheckPathBox.Text = Path.Combine(InstallPathBox.Text, "mods");

            AdminOwnerBox.Text = string.IsNullOrWhiteSpace(_config.GitHubOwner) ? Secrets.DefaultGitHubOwner : _config.GitHubOwner;
            AdminRepoBox.Text = string.IsNullOrWhiteSpace(_config.GitHubRepo) ? Secrets.DefaultGitHubRepo : _config.GitHubRepo;
            AdminTokenBox.Password = string.IsNullOrWhiteSpace(_config.GitHubToken) ? Secrets.DefaultGitHubToken : _config.GitHubToken;
            AdminMcPathBox.Text = MinecraftPaths.DefaultDotMinecraft();
        }

        // ---------- PLAYER TAB ----------

        private void BrowseInstallPathButton_Click(object sender, RoutedEventArgs e)
        {
            using var dialog = new System.Windows.Forms.FolderBrowserDialog();
            if (Directory.Exists(InstallPathBox.Text)) dialog.SelectedPath = InstallPathBox.Text;
            if (dialog.ShowDialog() == System.Windows.Forms.DialogResult.OK)
                InstallPathBox.Text = dialog.SelectedPath;
        }

        private async void RefreshButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                _config.GitHubOwner = ClientOwnerBox.Text.Trim();
                _config.GitHubRepo = ClientRepoBox.Text.Trim();
                _config.InstallPath = InstallPathBox.Text.Trim();
                _config.Save();

                var gh = new GitHubClient(_config.GitHubOwner, _config.GitHubRepo, "");
                var manifest = await gh.GetManifestAsync();
                _lastManifest = manifest;
                _packages.Clear();
                foreach (var p in manifest.Packages) _packages.Add(p);

                _tools.Clear();
                foreach (var t in manifest.Tools)
                {
                    var installed = ToolCheckService.IsInstalled(t.MatchSubstring);
                    _tools.Add(new ToolStatusVM
                    {
                        Name = t.Name,
                        DownloadUrl = t.DownloadUrl,
                        StatusText = installed ? "Установлено ✓" : "Не установлено",
                        InstallButtonVisibility = installed ? Visibility.Collapsed : Visibility.Visible
                    });
                }

                ClientStatusText.Foreground = System.Windows.Media.Brushes.DarkGreen;
                ClientStatusText.Text = $"Загружено сборок: {manifest.Packages.Count}, серверов: {manifest.Servers.Count}, программ: {manifest.Tools.Count}";
            }
            catch (Exception ex)
            {
                ClientStatusText.Foreground = System.Windows.Media.Brushes.DarkRed;
                ClientStatusText.Text = "Ошибка загрузки списка: " + ex.Message;
            }
        }

        private async void InstallPackageButton_Click(object sender, RoutedEventArgs e)
        {
            if (sender is not Button btn || btn.Tag is not PackageEntry pkg) return;
            try
            {
                ClientStatusText.Foreground = System.Windows.Media.Brushes.DarkGreen;
                var progress = new Progress<string>(msg => ClientStatusText.Text = msg);
                var installPath = InstallPathBox.Text.Trim();
                await InstallService.DownloadAndInstallAsync(pkg.DownloadUrl, installPath, pkg.Name, progress);
                ClientStatusText.Text = $"Готово: «{pkg.Name}» установлен в {installPath}";
            }
            catch (Exception ex)
            {
                ClientStatusText.Foreground = System.Windows.Media.Brushes.DarkRed;
                ClientStatusText.Text = "Ошибка установки: " + ex.Message;
            }
        }

        private void InstallServersButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (_lastManifest == null || _lastManifest.Servers.Count == 0)
                {
                    ClientStatusText.Foreground = System.Windows.Media.Brushes.DarkRed;
                    ClientStatusText.Text = "Сначала нажмите «Обновить список» — список серверов пуст.";
                    return;
                }

                var installPath = InstallPathBox.Text.Trim();
                var serversDatPath = Path.Combine(installPath, "servers.dat");
                var entries = _lastManifest.Servers
                    .Select(s => new ServerListEntry { Name = s.Name, Ip = s.Ip })
                    .ToList();

                NbtServerList.MergeAndWrite(serversDatPath, entries);

                ClientStatusText.Foreground = System.Windows.Media.Brushes.DarkGreen;
                ClientStatusText.Text = $"Добавлено серверов: {entries.Count}";
            }
            catch (Exception ex)
            {
                ClientStatusText.Foreground = System.Windows.Media.Brushes.DarkRed;
                ClientStatusText.Text = "Ошибка: " + ex.Message;
            }
        }

        private async void InstallToolButton_Click(object sender, RoutedEventArgs e)
        {
            if (sender is not Button btn || btn.Tag is not ToolStatusVM tool) return;
            try
            {
                ClientStatusText.Foreground = System.Windows.Media.Brushes.DarkGreen;
                ClientStatusText.Text = $"Скачиваю установщик «{tool.Name}»...";

                var ext = Path.GetExtension(new Uri(tool.DownloadUrl).LocalPath);
                if (string.IsNullOrEmpty(ext)) ext = ".exe";
                var tempPath = Path.Combine(Path.GetTempPath(), "mcsync_tool_" + Guid.NewGuid() + ext);

                using (var http = new HttpClient())
                using (var resp = await http.GetAsync(tool.DownloadUrl))
                {
                    resp.EnsureSuccessStatusCode();
                    await using var fs = File.Create(tempPath);
                    await resp.Content.CopyToAsync(fs);
                }

                ClientStatusText.Text = $"Запускаю установщик «{tool.Name}» — следуйте инструкциям в его окне, затем нажмите «Обновить список».";
                Process.Start(new ProcessStartInfo(tempPath) { UseShellExecute = true });
            }
            catch (Exception ex)
            {
                ClientStatusText.Foreground = System.Windows.Media.Brushes.DarkRed;
                ClientStatusText.Text = $"Ошибка установки «{tool.Name}»: " + ex.Message;
            }
        }

        private void BrowseModsCheckPathButton_Click(object sender, RoutedEventArgs e)
        {
            using var dialog = new System.Windows.Forms.FolderBrowserDialog();
            if (Directory.Exists(ModsCheckPathBox.Text)) dialog.SelectedPath = ModsCheckPathBox.Text;
            if (dialog.ShowDialog() == System.Windows.Forms.DialogResult.OK)
                ModsCheckPathBox.Text = dialog.SelectedPath;
        }

        private void ShowModsButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var path = ModsCheckPathBox.Text.Trim();
                if (!Directory.Exists(path))
                {
                    ModsFoundList.ItemsSource = new[] { "Папка не найдена." };
                    return;
                }

                var jars = Directory.GetFiles(path, "*.jar").Select(Path.GetFileName).ToArray();
                ModsFoundList.ItemsSource = jars.Length > 0 ? jars : new[] { "Модов не найдено в этой папке." };
            }
            catch (Exception ex)
            {
                ModsFoundList.ItemsSource = new[] { "Ошибка: " + ex.Message };
            }
        }

        // ---------- ADMIN TAB ----------

        private void AdminLoginButton_Click(object sender, RoutedEventArgs e)
        {
            var entered = AdminPasswordBox.Password;
            var hash = Hash(entered);
            var expected = string.IsNullOrEmpty(_config.AdminPasswordHash)
                ? Secrets.DefaultAdminPasswordHash
                : _config.AdminPasswordHash;

            if (string.IsNullOrEmpty(expected))
            {
                MessageBox.Show("Пароль администратора не задан в этой сборке приложения (Secrets.DefaultAdminPasswordHash пуст).");
                return;
            }

            if (hash == expected)
                AdminPanel.Visibility = Visibility.Visible;
            else
                MessageBox.Show("Неверный пароль.");
        }

        private void SaveNewPasswordButton_Click(object sender, RoutedEventArgs e)
        {
            var newPassword = NewAdminPasswordBox.Password;
            if (string.IsNullOrWhiteSpace(newPassword))
            {
                MessageBox.Show("Введите новый пароль.");
                return;
            }

            _config.AdminPasswordHash = Hash(newPassword);
            _config.Save();
            NewAdminPasswordBox.Clear();
            AdminStatusText.Foreground = System.Windows.Media.Brushes.DarkGreen;
            AdminStatusText.Text = "Пароль администратора обновлён (только на этом компьютере).";
        }

        private static string Hash(string input)
        {
            var bytes = SHA256.HashData(Encoding.UTF8.GetBytes(input));
            return Convert.ToBase64String(bytes);
        }

        private void BrowseMcPathButton_Click(object sender, RoutedEventArgs e)
        {
            using var dialog = new System.Windows.Forms.FolderBrowserDialog();
            if (Directory.Exists(AdminMcPathBox.Text)) dialog.SelectedPath = AdminMcPathBox.Text;
            if (dialog.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                AdminMcPathBox.Text = dialog.SelectedPath;
                ScanMcPathButton_Click(sender, e);
            }
        }

        private void ScanMcPathButton_Click(object sender, RoutedEventArgs e)
        {
            var path = AdminMcPathBox.Text.Trim();
            VersionsListBox.ItemsSource = MinecraftPaths.GetVersionFolders(path);
            WorldsListBox.ItemsSource = MinecraftPaths.GetSaveFolders(path);
        }

        private async void PublishButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                _config.GitHubOwner = AdminOwnerBox.Text.Trim();
                _config.GitHubRepo = AdminRepoBox.Text.Trim();
                _config.GitHubToken = AdminTokenBox.Password.Trim();
                _config.Save();

                var mcPath = AdminMcPathBox.Text.Trim();
                var selectedVersion = VersionsListBox.SelectedItem as string;
                var selectedWorld = WorldsListBox.SelectedItem as string;
                var packageName = string.IsNullOrWhiteSpace(PackageNameBox.Text) ? "Сборка" : PackageNameBox.Text.Trim();
                var packageId = "pkg-" + DateTime.UtcNow.ToString("yyyyMMdd-HHmmss");

                AdminStatusText.Foreground = System.Windows.Media.Brushes.DarkGreen;
                AdminStatusText.Text = "Собираю архив...";

                var zipPath = PackageBuilder.BuildPackageZip(
                    mcPath,
                    selectedVersion,
                    selectedWorld,
                    IncludeModsCheck.IsChecked == true,
                    IncludeConfigCheck.IsChecked == true,
                    IncludeResourcePacksCheck.IsChecked == true,
                    IncludeShaderPacksCheck.IsChecked == true,
                    Path.Combine(Path.GetTempPath(), "mcsync_out"),
                    packageId);

                AdminStatusText.Text = "Публикую релиз на GitHub...";
                var gh = new GitHubClient(_config.GitHubOwner, _config.GitHubRepo, _config.GitHubToken);
                var uploadUrl = await gh.CreateReleaseAsync(packageId, packageName, PackageDescriptionBox.Text);
                var downloadUrl = await gh.UploadReleaseAssetAsync(uploadUrl, zipPath);

                var manifest = await gh.GetManifestAsync();
                manifest.Packages.RemoveAll(p => p.Name == packageName);
                manifest.Packages.Add(new PackageEntry
                {
                    Id = packageId,
                    Name = packageName,
                    Description = PackageDescriptionBox.Text,
                    MinecraftVersion = selectedVersion ?? "",
                    Loader = (LoaderComboBox.SelectedItem as ComboBoxItem)?.Content?.ToString() ?? "",
                    Version = packageId,
                    DownloadUrl = downloadUrl,
                    IncludesWorld = selectedWorld != null,
                    PublishedAtUtc = DateTime.UtcNow.ToString("o")
                });

                await gh.UpdateManifestFileAsync(manifest);
                File.Delete(zipPath);

                AdminStatusText.Text = $"Опубликовано: {packageName}";
            }
            catch (Exception ex)
            {
                AdminStatusText.Foreground = System.Windows.Media.Brushes.DarkRed;
                AdminStatusText.Text = "Ошибка публикации: " + ex.Message;
            }
        }

        private async void PublishServersButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                _config.GitHubOwner = AdminOwnerBox.Text.Trim();
                _config.GitHubRepo = AdminRepoBox.Text.Trim();
                _config.GitHubToken = AdminTokenBox.Password.Trim();
                _config.Save();

                var lines = ServersTextBox.Text
                    .Split('\n', StringSplitOptions.RemoveEmptyEntries)
                    .Select(l => l.Trim())
                    .Where(l => l.Contains('|'));

                var gh = new GitHubClient(_config.GitHubOwner, _config.GitHubRepo, _config.GitHubToken);
                var manifest = await gh.GetManifestAsync();
                manifest.Servers.Clear();
                foreach (var line in lines)
                {
                    var parts = line.Split('|', 2);
                    manifest.Servers.Add(new ServerEntry { Name = parts[0].Trim(), Ip = parts[1].Trim() });
                }

                await gh.UpdateManifestFileAsync(manifest);

                AdminStatusText.Foreground = System.Windows.Media.Brushes.DarkGreen;
                AdminStatusText.Text = $"Опубликовано серверов: {manifest.Servers.Count}";
            }
            catch (Exception ex)
            {
                AdminStatusText.Foreground = System.Windows.Media.Brushes.DarkRed;
                AdminStatusText.Text = "Ошибка публикации серверов: " + ex.Message;
            }
        }

        private void BrowseToolFileButton_Click(object sender, RoutedEventArgs e)
        {
            var dialog = new Microsoft.Win32.OpenFileDialog
            {
                Filter = "Установщики (*.exe;*.msi)|*.exe;*.msi|Все файлы (*.*)|*.*"
            };
            if (dialog.ShowDialog() == true)
                ToolFilePathBox.Text = dialog.FileName;
        }

        private async void PublishToolButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                _config.GitHubOwner = AdminOwnerBox.Text.Trim();
                _config.GitHubRepo = AdminRepoBox.Text.Trim();
                _config.GitHubToken = AdminTokenBox.Password.Trim();
                _config.Save();

                var name = ToolNameBox.Text.Trim();
                var match = ToolMatchBox.Text.Trim();
                var filePath = ToolFilePathBox.Text.Trim();

                if (string.IsNullOrWhiteSpace(name) || string.IsNullOrWhiteSpace(filePath) || !File.Exists(filePath))
                {
                    MessageBox.Show("Укажите название программы и выберите файл установщика.");
                    return;
                }

                AdminStatusText.Foreground = System.Windows.Media.Brushes.DarkGreen;
                AdminStatusText.Text = $"Публикую «{name}»...";

                var gh = new GitHubClient(_config.GitHubOwner, _config.GitHubRepo, _config.GitHubToken);
                var toolId = "tool-" + name.Replace(" ", "_") + "-" + DateTime.UtcNow.ToString("yyyyMMdd-HHmmss");
                var uploadUrl = await gh.CreateReleaseAsync(toolId, name, "Установщик: " + name);
                var downloadUrl = await gh.UploadReleaseAssetAsync(uploadUrl, filePath, "application/octet-stream");

                var manifest = await gh.GetManifestAsync();
                manifest.Tools.RemoveAll(t => t.Name == name);
                manifest.Tools.Add(new ToolEntry { Name = name, MatchSubstring = match, DownloadUrl = downloadUrl });
                await gh.UpdateManifestFileAsync(manifest);

                AdminStatusText.Text = $"Опубликована программа: {name}";
            }
            catch (Exception ex)
            {
                AdminStatusText.Foreground = System.Windows.Media.Brushes.DarkRed;
                AdminStatusText.Text = "Ошибка публикации программы: " + ex.Message;
            }
        }
    }
}
