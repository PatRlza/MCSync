using System.Collections.Generic;

namespace MCSync.Models
{
    // The manifest.json file that lives in the GitHub repo and lists
    // everything clients can see: published builds ("packages") and
    // the shared server list.
    public class Manifest
    {
        public List<PackageEntry> Packages { get; set; } = new();
        public List<ServerEntry> Servers { get; set; } = new();
        public List<ToolEntry> Tools { get; set; } = new();
    }

    // A required external program (Radmin VPN, a launcher, etc.) that players
    // need installed. MatchSubstring is looked up in the Windows "installed
    // programs" list to decide whether it's already installed.
    public class ToolEntry
    {
        public string Name { get; set; } = "";
        public string MatchSubstring { get; set; } = "";
        public string DownloadUrl { get; set; } = "";
    }

    public class PackageEntry
    {
        public string Id { get; set; } = "";
        public string Name { get; set; } = "";
        public string Description { get; set; } = "";
        public string MinecraftVersion { get; set; } = "";
        public string Loader { get; set; } = ""; // forge / fabric / neoforge / vanilla
        public string Version { get; set; } = "";
        public string DownloadUrl { get; set; } = "";
        public bool IncludesWorld { get; set; }
        public string PublishedAtUtc { get; set; } = "";
    }

    public class ServerEntry
    {
        public string Name { get; set; } = "";
        public string Ip { get; set; } = "";
    }
}
