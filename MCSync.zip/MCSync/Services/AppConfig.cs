using System;
using System.IO;
using System.Text.Json;

namespace MCSync.Services
{
    public class AppConfig
    {
        public string GitHubOwner { get; set; } = "";
        public string GitHubRepo { get; set; } = "";
        public string GitHubToken { get; set; } = ""; // only needed for admin publishing
        public string InstallPath { get; set; } = "";
        public string AdminPasswordHash { get; set; } = "";

        private static string ConfigPath =>
            Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "MCSync", "config.json");

        public static AppConfig Load()
        {
            try
            {
                if (File.Exists(ConfigPath))
                {
                    var json = File.ReadAllText(ConfigPath);
                    var cfg = JsonSerializer.Deserialize<AppConfig>(json);
                    if (cfg != null) return cfg;
                }
            }
            catch
            {
                // corrupt/unreadable config -> start fresh rather than crash
            }
            return new AppConfig();
        }

        public void Save()
        {
            var dir = Path.GetDirectoryName(ConfigPath)!;
            Directory.CreateDirectory(dir);
            var json = JsonSerializer.Serialize(this, new JsonSerializerOptions { WriteIndented = true });
            File.WriteAllText(ConfigPath, json);
        }
    }
}
