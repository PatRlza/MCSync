using System;
using System.IO;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using MCSync.Models;

namespace MCSync.Services
{
    // Talks to a single GitHub repo. Reading the manifest needs no token
    // (works for a public repo). Publishing (creating releases, uploading
    // assets, updating manifest.json) needs a token with repo access.
    public class GitHubClient
    {
        private readonly HttpClient _http;
        private readonly string _owner;
        private readonly string _repo;

        public GitHubClient(string owner, string repo, string token)
        {
            _owner = owner;
            _repo = repo;
            _http = new HttpClient();
            _http.DefaultRequestHeaders.UserAgent.ParseAdd("MCSyncApp");
            _http.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/vnd.github+json"));
            if (!string.IsNullOrWhiteSpace(token))
                _http.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);
        }

        // Reads manifest.json straight from the repo's default branch (assumed "main").
        public async Task<Manifest> GetManifestAsync()
        {
            var url = $"https://raw.githubusercontent.com/{_owner}/{_repo}/main/manifest.json?_={DateTime.UtcNow.Ticks}";
            using var resp = await _http.GetAsync(url);
            if (!resp.IsSuccessStatusCode)
                return new Manifest();

            var json = await resp.Content.ReadAsStringAsync();
            var manifest = JsonSerializer.Deserialize<Manifest>(json, new JsonSerializerOptions { PropertyNameCaseInsensitive = true });
            return manifest ?? new Manifest();
        }

        public async Task<string> CreateReleaseAsync(string tagName, string name, string body)
        {
            var url = $"https://api.github.com/repos/{_owner}/{_repo}/releases";
            var payload = JsonSerializer.Serialize(new { tag_name = tagName, name, body, draft = false, prerelease = false });
            using var content = new StringContent(payload, Encoding.UTF8, "application/json");
            using var resp = await _http.PostAsync(url, content);
            resp.EnsureSuccessStatusCode();
            var respJson = await resp.Content.ReadAsStringAsync();
            using var doc = JsonDocument.Parse(respJson);
            var uploadUrlTemplate = doc.RootElement.GetProperty("upload_url").GetString()!;
            return uploadUrlTemplate.Split('{')[0]; // strip the {?name,label} template part
        }

        public async Task<string> UploadReleaseAssetAsync(string uploadUrlBase, string filePath, string contentType = "application/zip")
        {
            var fileName = Path.GetFileName(filePath);
            var url = $"{uploadUrlBase}?name={Uri.EscapeDataString(fileName)}";
            var bytes = await File.ReadAllBytesAsync(filePath);
            using var content = new ByteArrayContent(bytes);
            content.Headers.ContentType = new MediaTypeHeaderValue(contentType);
            using var resp = await _http.PostAsync(url, content);
            resp.EnsureSuccessStatusCode();
            var respJson = await resp.Content.ReadAsStringAsync();
            using var doc = JsonDocument.Parse(respJson);
            return doc.RootElement.GetProperty("browser_download_url").GetString()!;
        }

        public async Task UpdateManifestFileAsync(Manifest manifest)
        {
            var contentsUrl = $"https://api.github.com/repos/{_owner}/{_repo}/contents/manifest.json";
            string? sha = null;
            using (var getResp = await _http.GetAsync(contentsUrl))
            {
                if (getResp.IsSuccessStatusCode)
                {
                    var getJson = await getResp.Content.ReadAsStringAsync();
                    using var doc = JsonDocument.Parse(getJson);
                    sha = doc.RootElement.GetProperty("sha").GetString();
                }
            }

            var manifestJson = JsonSerializer.Serialize(manifest, new JsonSerializerOptions { WriteIndented = true });
            var base64 = Convert.ToBase64String(Encoding.UTF8.GetBytes(manifestJson));

            object payloadObj = sha == null
                ? new { message = "Update manifest", content = base64 }
                : new { message = "Update manifest", content = base64, sha };

            var payload = JsonSerializer.Serialize(payloadObj);
            using var content = new StringContent(payload, Encoding.UTF8, "application/json");
            using var putResp = await _http.PutAsync(contentsUrl, content);
            putResp.EnsureSuccessStatusCode();
        }
    }
}
