using System;
using System.IO;
using System.IO.Compression;
using System.Net.Http;
using System.Text.Json;
using System.Text.Json.Nodes;
using System.Threading.Tasks;

namespace MCSync.Services
{
    public static class InstallService
    {
        public static async Task DownloadAndInstallAsync(
            string downloadUrl,
            string targetDotMinecraft,
            string? profileName,
            IProgress<string>? progress = null)
        {
            Directory.CreateDirectory(targetDotMinecraft);
            var tempZip = Path.Combine(Path.GetTempPath(), "mcsync_download_" + Guid.NewGuid() + ".zip");

            progress?.Report("Скачивание...");
            using (var http = new HttpClient())
            using (var resp = await http.GetAsync(downloadUrl))
            {
                resp.EnsureSuccessStatusCode();
                await using var fs = File.Create(tempZip);
                await resp.Content.CopyToAsync(fs);
            }

            progress?.Report("Распаковка...");
            ZipFile.ExtractToDirectory(tempZip, targetDotMinecraft, overwriteFiles: true);
            File.Delete(tempZip);

            // The package includes a versions/<id> folder as it was on the admin's
            // machine, so find it and register it as a launcher profile.
            var versionsDir = Path.Combine(targetDotMinecraft, "versions");
            if (Directory.Exists(versionsDir))
            {
                foreach (var versionFolder in Directory.GetDirectories(versionsDir))
                {
                    var versionId = Path.GetFileName(versionFolder);
                    progress?.Report("Настройка профиля лаунчера...");
                    TryAddLauncherProfile(targetDotMinecraft, versionId, profileName ?? versionId);
                }
            }

            progress?.Report("Готово.");
        }

        private static void TryAddLauncherProfile(string dotMinecraftPath, string versionId, string profileName)
        {
            try
            {
                var profilesPath = Path.Combine(dotMinecraftPath, "launcher_profiles.json");
                JsonNode root = File.Exists(profilesPath)
                    ? (JsonNode.Parse(File.ReadAllText(profilesPath)) ?? new JsonObject())
                    : new JsonObject();

                if (root["profiles"] is not JsonObject)
                    root["profiles"] = new JsonObject();

                var profiles = (JsonObject)root["profiles"]!;
                var profileId = "mcsync-" + versionId;
                profiles[profileId] = new JsonObject
                {
                    ["name"] = profileName,
                    ["type"] = "custom",
                    ["lastVersionId"] = versionId,
                    ["icon"] = "Furnace"
                };

                if (root["settings"] is not JsonObject)
                {
                    root["settings"] = new JsonObject
                    {
                        ["enableSnapshots"] = false,
                        ["enableAdvanced"] = true
                    };
                }

                File.WriteAllText(profilesPath, root.ToJsonString(new JsonSerializerOptions { WriteIndented = true }));
            }
            catch
            {
                // best-effort only: if this fails the user can still add the profile by hand
            }
        }
    }
}
