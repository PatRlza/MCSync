using System;
using System.IO;
using System.Linq;

namespace MCSync.Services
{
    public static class MinecraftPaths
    {
        public static string DefaultDotMinecraft()
        {
            var appData = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData);
            return Path.Combine(appData, ".minecraft");
        }

        public static string[] GetVersionFolders(string dotMinecraftPath)
        {
            var versionsDir = Path.Combine(dotMinecraftPath, "versions");
            if (!Directory.Exists(versionsDir)) return Array.Empty<string>();
            return Directory.GetDirectories(versionsDir)
                .Select(Path.GetFileName)
                .Where(n => n != null)
                .Select(n => n!)
                .ToArray();
        }

        public static string[] GetSaveFolders(string dotMinecraftPath)
        {
            var savesDir = Path.Combine(dotMinecraftPath, "saves");
            if (!Directory.Exists(savesDir)) return Array.Empty<string>();
            return Directory.GetDirectories(savesDir)
                .Select(Path.GetFileName)
                .Where(n => n != null)
                .Select(n => n!)
                .ToArray();
        }
    }
}
