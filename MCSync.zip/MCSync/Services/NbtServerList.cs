using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Compression;
using System.Text;

namespace MCSync.Services
{
    public class ServerListEntry
    {
        public string Name { get; set; } = "";
        public string Ip { get; set; } = "";
    }

    // Minecraft's servers.dat is a gzip-compressed NBT file with a "servers"
    // list of compounds, each having (at least) "name" and "ip" strings.
    // This implements just enough of the NBT binary format to read and
    // write that one structure.
    public static class NbtServerList
    {
        public static List<ServerListEntry> ReadServersDat(string path)
        {
            var result = new List<ServerListEntry>();
            if (!File.Exists(path)) return result;
            try
            {
                using var fs = File.OpenRead(path);
                using var gz = new GZipStream(fs, CompressionMode.Decompress);
                using var ms = new MemoryStream();
                gz.CopyTo(ms);
                ms.Position = 0;
                using var br = new BinaryReader(ms);

                byte rootType = br.ReadByte();
                if (rootType != 10) return result; // expected TAG_Compound
                ReadStringBE(br); // root name, usually empty

                ReadCompoundBody(br, result);
            }
            catch
            {
                // unreadable/corrupt file -> treat as empty, caller will (re)write it
            }
            return result;
        }

        private static void ReadCompoundBody(BinaryReader br, List<ServerListEntry> result)
        {
            while (true)
            {
                byte type = br.ReadByte();
                if (type == 0) break; // TAG_End
                string name = ReadStringBE(br);
                if (type == 9 && name == "servers") // TAG_List
                {
                    byte elemType = br.ReadByte();
                    int count = ReadInt32BE(br);
                    for (int i = 0; i < count; i++)
                    {
                        if (elemType == 10)
                        {
                            var entry = new ServerListEntry();
                            while (true)
                            {
                                byte innerType = br.ReadByte();
                                if (innerType == 0) break;
                                string innerName = ReadStringBE(br);
                                if (innerType == 8)
                                {
                                    string val = ReadStringBE(br);
                                    if (innerName == "name") entry.Name = val;
                                    else if (innerName == "ip") entry.Ip = val;
                                }
                                else
                                {
                                    SkipPayload(br, innerType);
                                }
                            }
                            result.Add(entry);
                        }
                        else
                        {
                            SkipPayload(br, elemType);
                        }
                    }
                }
                else
                {
                    SkipPayload(br, type);
                }
            }
        }

        private static void SkipPayload(BinaryReader br, byte type)
        {
            switch (type)
            {
                case 1: br.ReadByte(); break;
                case 2: br.ReadBytes(2); break;
                case 3: br.ReadBytes(4); break;
                case 4: br.ReadBytes(8); break;
                case 5: br.ReadBytes(4); break;
                case 6: br.ReadBytes(8); break;
                case 7: { int len = ReadInt32BE(br); br.ReadBytes(len); break; }
                case 8: ReadStringBE(br); break;
                case 9:
                    {
                        byte elemType = br.ReadByte();
                        int count = ReadInt32BE(br);
                        for (int i = 0; i < count; i++) SkipPayload(br, elemType);
                        break;
                    }
                case 10:
                    {
                        while (true)
                        {
                            byte innerType = br.ReadByte();
                            if (innerType == 0) break;
                            ReadStringBE(br);
                            SkipPayload(br, innerType);
                        }
                        break;
                    }
                case 11: { int len = ReadInt32BE(br); br.ReadBytes(len * 4); break; }
                case 12: { int len = ReadInt32BE(br); br.ReadBytes(len * 8); break; }
            }
        }

        private static string ReadStringBE(BinaryReader br)
        {
            int len = ReadUInt16BE(br);
            var bytes = br.ReadBytes(len);
            return Encoding.UTF8.GetString(bytes);
        }

        private static int ReadUInt16BE(BinaryReader br)
        {
            byte a = br.ReadByte(), b = br.ReadByte();
            return (a << 8) | b;
        }

        private static int ReadInt32BE(BinaryReader br)
        {
            byte a = br.ReadByte(), b = br.ReadByte(), c = br.ReadByte(), d = br.ReadByte();
            return (a << 24) | (b << 16) | (c << 8) | d;
        }

        public static void WriteServersDat(string path, List<ServerListEntry> entries)
        {
            using var ms = new MemoryStream();
            using (var bw = new BinaryWriter(ms))
            {
                bw.Write((byte)10); // TAG_Compound (root)
                WriteStringBE(bw, "");

                bw.Write((byte)9); // TAG_List
                WriteStringBE(bw, "servers");
                bw.Write((byte)10); // element type: TAG_Compound
                WriteInt32BE(bw, entries.Count);

                foreach (var e in entries)
                {
                    bw.Write((byte)8); WriteStringBE(bw, "name"); WriteStringBE(bw, e.Name);
                    bw.Write((byte)8); WriteStringBE(bw, "ip"); WriteStringBE(bw, e.Ip);
                    bw.Write((byte)0); // TAG_End of this list entry
                }

                bw.Write((byte)0); // TAG_End of root compound
            }

            ms.Position = 0;
            var dir = Path.GetDirectoryName(path);
            if (!string.IsNullOrEmpty(dir)) Directory.CreateDirectory(dir);
            using var fs = File.Create(path);
            using var gz = new GZipStream(fs, CompressionMode.Compress);
            ms.CopyTo(gz);
        }

        private static void WriteStringBE(BinaryWriter bw, string s)
        {
            var bytes = Encoding.UTF8.GetBytes(s);
            WriteUInt16BE(bw, (ushort)bytes.Length);
            bw.Write(bytes);
        }

        private static void WriteUInt16BE(BinaryWriter bw, ushort v)
        {
            bw.Write((byte)((v >> 8) & 0xFF));
            bw.Write((byte)(v & 0xFF));
        }

        private static void WriteInt32BE(BinaryWriter bw, int v)
        {
            bw.Write((byte)((v >> 24) & 0xFF));
            bw.Write((byte)((v >> 16) & 0xFF));
            bw.Write((byte)((v >> 8) & 0xFF));
            bw.Write((byte)(v & 0xFF));
        }

        // Adds new entries to whatever is already in servers.dat, skipping
        // duplicates by IP, and writes the combined list back.
        public static void MergeAndWrite(string path, List<ServerListEntry> newEntries)
        {
            var existing = ReadServersDat(path);
            foreach (var ne in newEntries)
            {
                if (!existing.Exists(e => e.Ip == ne.Ip))
                    existing.Add(ne);
            }
            WriteServersDat(path, existing);
        }
    }
}
