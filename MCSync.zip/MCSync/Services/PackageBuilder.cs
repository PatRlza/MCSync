using System.IO;
using System.IO.Compression;

namespace MCSync.Services
{
    public static class PackageBuilder
    {
        // Copies the chosen pieces of a .minecraft instance (a version folder,
        // a world, and optionally mods/config/resourcepacks/shaderpacks) into a
        // staging folder mirroring .minecraft's own layout, then zips it.
        public static string BuildPackageZip(
            string dotMinecraftPath,
            string? versionFolder,
            string? worldFolder,
            bool includeMods,
            bool includeConfig,
            bool includeResourcePacks,
            bool includeShaderPacks,
            string outputDirectory,
            string packageId)
        {
            var staging = Path.Combine(Path.GetTempPath(), "mcsync_stage_" + packageId);
            if (Directory.Exists(staging)) Directory.Delete(staging, true);
            Directory.CreateDirectory(staging);

            void CopyTopLevel(string relative)
            {
                var src = Path.Combine(dotMinecraftPath, relative);
                if (!Directory.Exists(src)) return;
                CopyDirectoryRecursive(src, Path.Combine(staging, relative));
            }

            if (versionFolder != null)
                CopyDirectoryRecursive(
                    Path.Combine(dotMinecraftPath, "versions", versionFolder),
                    Path.Combine(staging, "versions", versionFolder));

            if (worldFolder != null)
                CopyDirectoryRecursive(
                    Path.Combine(dotMinecraftPath, "saves", worldFolder),
                    Path.Combine(staging, "saves", worldFolder));

            if (includeMods) CopyTopLevel("mods");
            if (includeConfig) CopyTopLevel("config");
            if (includeResourcePacks) CopyTopLevel("resourcepacks");
            if (includeShaderPacks) CopyTopLevel("shaderpacks");

            Directory.CreateDirectory(outputDirectory);
            var zipPath = Path.Combine(outputDirectory, packageId + ".zip");
            if (File.Exists(zipPath)) File.Delete(zipPath);
            ZipFile.CreateFromDirectory(staging, zipPath);

            Directory.Delete(staging, true);
            return zipPath;
        }

        private static void CopyDirectoryRecursive(string sourceDir, string destDir)
        {
            Directory.CreateDirectory(destDir);
            foreach (var file in Directory.GetFiles(sourceDir))
            {
                var destFile = Path.Combine(destDir, Path.GetFileName(file));
                File.Copy(file, destFile, true);
            }
            foreach (var dir in Directory.GetDirectories(sourceDir))
            {
                var destSubDir = Path.Combine(destDir, Path.GetFileName(dir));
                CopyDirectoryRecursive(dir, destSubDir);
            }
        }
    }
}
