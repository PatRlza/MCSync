namespace MCSync.Services
{
    // Fill these in with your own values BEFORE building your copy of the app,
    // then run dotnet publish again. Nothing here is downloaded from anywhere —
    // it gets baked straight into the compiled .exe, so players who just run
    // the app can't see or change it (they don't have your source code).
    //
    // To generate the password hash, run this in PowerShell:
    //   [Convert]::ToBase64String((New-Object Security.Cryptography.SHA256Managed).ComputeHash([Text.Encoding]::UTF8.GetBytes("YOUR_PASSWORD_HERE")))
    // then paste the result below.
    public static class Secrets
    {
        public const string DefaultAdminPasswordHash = ""; // paste the PowerShell output here
        public const string DefaultGitHubToken = "";        // your GitHub token (only used for publishing)
        public const string DefaultGitHubOwner = "";         // e.g. "yourusername"
        public const string DefaultGitHubRepo = "";          // e.g. "our-minecraft"
    }
}
