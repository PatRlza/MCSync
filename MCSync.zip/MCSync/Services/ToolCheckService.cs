using System;
using Microsoft.Win32;

namespace MCSync.Services
{
    // Scans the standard "installed programs" registry locations for any
    // entry whose display name contains the given substring. This works for
    // any normal Windows installer (Radmin VPN, launchers, etc.) without
    // needing to know its exact install path in advance.
    public static class ToolCheckService
    {
        public static bool IsInstalled(string matchSubstring)
        {
            if (string.IsNullOrWhiteSpace(matchSubstring)) return false;

            string[] uninstallPaths =
            {
                @"SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall",
                @"SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall"
            };

            foreach (var path in uninstallPaths)
            {
                if (ScanKey(Registry.LocalMachine, path, matchSubstring)) return true;
                if (ScanKey(Registry.CurrentUser, path, matchSubstring)) return true;
            }
            return false;
        }

        private static bool ScanKey(RegistryKey hive, string path, string matchSubstring)
        {
            try
            {
                using var key = hive.OpenSubKey(path);
                if (key == null) return false;

                foreach (var subKeyName in key.GetSubKeyNames())
                {
                    using var subKey = key.OpenSubKey(subKeyName);
                    if (subKey?.GetValue("DisplayName") is string displayName &&
                        displayName.Contains(matchSubstring, StringComparison.OrdinalIgnoreCase))
                        return true;
                }
            }
            catch
            {
                // inaccessible registry key -> treat as "not found" rather than crash
            }
            return false;
        }
    }
}
